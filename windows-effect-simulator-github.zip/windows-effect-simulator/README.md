# Windows Effect Simulator

A Windows-only Python experiment that displays a fullscreen overlay using captured desktop frames and can toggle the Windows Color Filters shortcut.

> **Important:** The 10 FPS mode only limits how often the overlay image is refreshed. It does not limit the actual FPS of games or other applications. Screen-capture exclusion depends on Windows version and capture API; the fallback temporarily hides the overlay before capturing.

## Features

- Toggle Windows Color Filters with `Ctrl + W + Esc`.
- Toggle the visual 10 FPS overlay with `Esc`, `1`, and `E` held together.
- Press `Esc` twice within 0.4 seconds to disable the effects and restore the color-filter state recorded at startup.
- Press `F12` to exit and attempt to restore the startup color-filter state.
- Click-through, topmost overlay window.

## Requirements

- Windows 10/11
- Python 3.10 or newer recommended
- `keyboard`, `mss`, and `Pillow`
- Tkinter (usually included with the standard Windows Python installer)

## Setup

Open PowerShell in this folder and install dependencies:

```powershell
py -m pip install -r requirements.txt
```

Run the program:

```powershell
py windows_effect_simulator.py
```

The program requests Administrator permission because global keyboard hooks and system-wide hotkeys may require elevation. If Windows Color Filters does not respond, check **Settings → Accessibility → Color filters** and make sure its keyboard shortcut is enabled.

## Hotkeys

| Shortcut | Action |
| --- | --- |
| `Ctrl + W + Esc` (hold together) | Toggle Windows Color Filters |
| `Esc + 1 + E` (hold together) | Toggle the 10 FPS overlay simulation |
| `Esc`, then `Esc` again within 0.4 seconds | Disable effects and restore the initial color-filter state |
| `F12` | Exit |

**Caution:** `Ctrl + W` is also a common browser shortcut for closing a tab. Avoid triggering the grayscale shortcut while typing or working in an application where that combination has side effects.

## Limitations

- This project has not been validated across all Windows versions, GPU drivers, multi-monitor layouts, or fullscreen applications.
- `SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE)` is best-effort and may not exclude the overlay from every capture path.
- The fallback capture path hides the overlay temporarily, which can cause visible flicker.
- The color-filter registry value may be unavailable or may not update if Windows Color Filters or its keyboard shortcut is disabled.
- Use at your own risk; test in a non-critical session first.

## License

No license has been specified yet. Until a license is added, others should not assume they have permission to redistribute or modify this project.

## Build a Windows EXE

On a Windows PC, install Python from https://www.python.org/downloads/windows/ and enable **Add Python to PATH** during setup. Then double-click `build_exe.bat`. The finished file will be created at `dist\WindowsEffectSimulator.exe`. The build script installs PyInstaller and the required packages automatically.

You can also upload this repository to GitHub, open **Actions**, select **Build Windows EXE**, and click **Run workflow**. When it finishes, download the `WindowsEffectSimulator-Windows` artifact from the workflow run.

The EXE has not been runtime-tested on Windows yet. Test it locally before distributing it. Windows may show a security warning for an unsigned EXE.
