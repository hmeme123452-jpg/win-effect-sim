@echo off
setlocal
cd /d "%~dp0"

echo =============================================
echo Windows Effect Simulator - EXE Builder
echo =============================================

where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python was not found.
    echo Install Python from https://www.python.org/downloads/windows/
    echo During setup, enable "Add Python to PATH".
    pause
    exit /b 1
)

echo [1/4] Updating pip...
py -m pip install --upgrade pip
if errorlevel 1 goto failed

echo [2/4] Installing app dependencies...
py -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo [3/4] Installing PyInstaller...
py -m pip install pyinstaller
if errorlevel 1 goto failed

echo [4/4] Building EXE...
py -m PyInstaller --noconfirm --clean --onefile --windowed --name WindowsEffectSimulator --hidden-import=PIL.ImageTk windows_effect_simulator.py
if errorlevel 1 goto failed

echo.
echo BUILD COMPLETE!
echo EXE location: %~dp0dist\WindowsEffectSimulator.exe
echo Test the EXE on Windows before sharing it.
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Read the error message above.
pause
exit /b 1
