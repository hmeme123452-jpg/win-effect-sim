import os
import sys

if os.name != "nt":
    raise SystemExit("Chương trình chỉ hỗ trợ Windows.")

import ctypes
import queue
import signal
import threading
import time
import tkinter as tk
import winreg
from ctypes import wintypes

import keyboard
import mss
from PIL import Image, ImageTk

# =========================================================
# CẤU HÌNH
# =========================================================
TARGET_FPS = 10
FRAME_INTERVAL = 1.0 / TARGET_FPS
POLL_INTERVAL_MS = 10
MONITOR_INDEX = 1  # mss: 0 = toàn bộ desktop ảo, 1 = màn hình chính
ESC_DOUBLE_PRESS_INTERVAL = 0.4
USE_CAPTURE_EXCLUSION = True
COLOR_FILTER_WAIT = 0.6
HIDE_SETTLE_MS = 40

CHORD_GRAYSCALE = frozenset({"ctrl", "w", "esc"})
CHORD_FPS = frozenset({"esc", "1", "e"})

# =========================================================
# TRẠNG THÁI CHUNG
# =========================================================
running = True
fps_enabled = False
root = None
screen_label = None
photo_image = None
overlay_visible = False
capture_excluded = False
capture_in_progress = False
monitor_rect = None

command_queue = queue.Queue()
frame_queue = queue.Queue(maxsize=1)
hide_queue = queue.Queue()
state_lock = threading.Lock()
hotkey_lock = threading.Lock()
stop_event = threading.Event()
initial_filter_state = None
pressed_keys = {}  # scan_code -> tên phím chuẩn hóa
triggered_chords = set()
last_esc_press = 0.0

# =========================================================
# WIN32 CONSTANTS / API
# =========================================================
GWL_EXSTYLE = -20
GA_ROOT = 2
LWA_ALPHA = 0x02

WS_EX_TRANSPARENT = 0x20
WS_EX_TOOLWINDOW = 0x80
WS_EX_LAYERED = 0x80000
WS_EX_NOACTIVATE = 0x08000000
OVERLAY_EX_STYLE = (
    WS_EX_TRANSPARENT
    | WS_EX_TOOLWINDOW
    | WS_EX_LAYERED
    | WS_EX_NOACTIVATE
)
WDA_EXCLUDEFROMCAPTURE = 0x00000011

user32 = ctypes.WinDLL("user32", use_last_error=True)
user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
user32.GetAncestor.restype = wintypes.HWND
user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetWindowLongW.restype = ctypes.c_long
user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
user32.SetWindowLongW.restype = ctypes.c_long
user32.SetLayeredWindowAttributes.argtypes = [
    wintypes.HWND, wintypes.DWORD, ctypes.c_ubyte, wintypes.DWORD
]
user32.SetLayeredWindowAttributes.restype = wintypes.BOOL
user32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.SetWindowDisplayAffinity.restype = wintypes.BOOL
user32.GetWindowDisplayAffinity.argtypes = [
    wintypes.HWND, ctypes.POINTER(wintypes.DWORD)
]
user32.GetWindowDisplayAffinity.restype = wintypes.BOOL

# =========================================================
# ADMINISTRATOR / DPI
# =========================================================
def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def request_admin():
    if is_admin():
        return

    script_path = os.path.abspath(__file__)
    shell_execute = ctypes.windll.shell32.ShellExecuteW
    shell_execute.restype = ctypes.c_void_p
    shell_execute.argtypes = [
        wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR,
        wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.c_int
    ]

    result = shell_execute(
        None, "runas", sys.executable, f'"{script_path}"',
        os.path.dirname(script_path), 1
    )
    if (result or 0) <= 32:
        print("Không thể yêu cầu quyền Administrator.")
        try:
            input("Nhấn Enter để thoát.")
        except EOFError:
            pass
    raise SystemExit


def enable_dpi_awareness():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

# =========================================================
# WINDOWS COLOR FILTER
# =========================================================
def read_filter_state():
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\ColorFiltering",
            0,
            winreg.KEY_READ,
        ) as key:
            value, _ = winreg.QueryValueEx(key, "Active")
            return bool(value)
    except OSError:
        return None


def toggle_windows_color_filter():
    before = read_filter_state()
    try:
        keyboard.send("windows+ctrl+c")
    except Exception as exc:
        print(f"[COLOR ERROR] {exc}")
        return before, before

    deadline = time.monotonic() + COLOR_FILTER_WAIT
    after = before
    while time.monotonic() < deadline:
        time.sleep(0.05)
        after = read_filter_state()
        if after != before:
            break
    return before, after


def toggle_grayscale():
    if not running:
        return
    before, after = toggle_windows_color_filter()
    if before is None or after is None:
        print("[COLOR] Đã gửi phím tắt; không xác minh được trạng thái registry.")
    elif before != after:
        print("[COLOR] Bộ lọc màu:", "BẬT" if after else "TẮT")
    else:
        print("[COLOR] Trạng thái không đổi. Kiểm tra cài đặt Color Filters và phím tắt Win+Ctrl+C.")


def restore_color_filter():
    if initial_filter_state is None:
        return
    current = read_filter_state()
    if current is not None and current != initial_filter_state:
        toggle_windows_color_filter()

# =========================================================
# OVERLAY WINDOW
# =========================================================
def get_overlay_hwnd():
    child = root.winfo_id()
    return user32.GetAncestor(child, GA_ROOT) or child


def exclude_from_capture(hwnd):
    affinity = wintypes.DWORD(0)
    if (
        user32.GetWindowDisplayAffinity(hwnd, ctypes.byref(affinity))
        and affinity.value == WDA_EXCLUDEFROMCAPTURE
    ):
        return True
    return bool(user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE))


def configure_overlay_window():
    global capture_excluded
    try:
        hwnd = get_overlay_hwnd()
        style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        if (style & OVERLAY_EX_STYLE) != OVERLAY_EX_STYLE:
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style | OVERLAY_EX_STYLE)
        # Gọi lại an toàn; đảm bảo cửa sổ layered có alpha.
        user32.SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA)
        capture_excluded = USE_CAPTURE_EXCLUSION and exclude_from_capture(hwnd)
    except Exception as exc:
        capture_excluded = False
        print(f"[OVERLAY WARNING] {exc}")


def create_window():
    global root, screen_label
    root = tk.Tk()
    root.title("Windows Effect Simulator")
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.configure(bg="black")
    screen_label = tk.Label(root, bg="black", borderwidth=0, highlightthickness=0)
    screen_label.pack(fill="both", expand=True)
    root.geometry("1x1+0+0")
    root.update()
    configure_overlay_window()
    root.withdraw()


def show_overlay():
    global overlay_visible
    if overlay_visible:
        return
    root.geometry(
        f"{monitor_rect['width']}x{monitor_rect['height']}"
        f"{monitor_rect['left']:+d}{monitor_rect['top']:+d}"
    )
    root.deiconify()
    root.attributes("-topmost", True)
    configure_overlay_window()
    overlay_visible = True


def hide_overlay():
    global overlay_visible
    if overlay_visible:
        root.withdraw()
        overlay_visible = False

# =========================================================
# FRAME QUEUE
# =========================================================
def put_latest_frame(image):
    try:
        frame_queue.put_nowait(image)
    except queue.Full:
        try:
            frame_queue.get_nowait()
        except queue.Empty:
            pass
        try:
            frame_queue.put_nowait(image)
        except queue.Full:
            pass


def clear_frame_queue():
    while True:
        try:
            frame_queue.get_nowait()
        except queue.Empty:
            break

# =========================================================
# CAPTURE THREAD
# =========================================================
def get_monitor_rect():
    with mss.mss() as sct:
        if MONITOR_INDEX < 1 or MONITOR_INDEX >= len(sct.monitors):
            return None
        return dict(sct.monitors[MONITOR_INDEX])


def request_overlay_hidden():
    """Chờ UI ẩn overlay trước khi chụp trong chế độ dự phòng."""
    ack = threading.Event()
    hide_queue.put(ack)
    return ack.wait(timeout=1.0)


def capture_loop(monitor):
    try:
        with mss.mss() as sct:
            while not stop_event.is_set():
                with state_lock:
                    active = fps_enabled
                if not active:
                    stop_event.wait(0.05)
                    continue

                started = time.perf_counter()
                if not capture_excluded:
                    if not request_overlay_hidden():
                        continue

                if stop_event.is_set():
                    break
                with state_lock:
                    active = fps_enabled
                if not active:
                    continue

                try:
                    shot = sct.grab(monitor)
                    image = Image.frombytes(
                        "RGB", shot.size, shot.bgra, "raw", "BGRX"
                    )
                    put_latest_frame(image)
                except Exception as exc:
                    print(f"[CAPTURE ERROR] {exc}")
                finally:
                    # Báo UI rằng đã chụp xong; chỉ lúc đó mới được hiện frame mới.
                    if not capture_excluded:
                        command_queue.put("capture_done")

                remaining = FRAME_INTERVAL - (time.perf_counter() - started)
                if remaining > 0:
                    stop_event.wait(remaining)
    except Exception as exc:
        print(f"[MSS ERROR] {exc}")

# =========================================================
# EFFECT CONTROLS
# =========================================================
def toggle_fps():
    global fps_enabled, capture_in_progress
    with state_lock:
        fps_enabled = not fps_enabled
        enabled = fps_enabled
    clear_frame_queue()
    if enabled:
        print(f"[FPS] Bật mô phỏng cập nhật hình ảnh {TARGET_FPS} FPS.")
    else:
        capture_in_progress = False
        hide_overlay()
        print("[FPS] Đã tắt mô phỏng.")


def disable_all_effects():
    global fps_enabled, capture_in_progress
    with state_lock:
        fps_enabled = False
    capture_in_progress = False
    hide_overlay()
    clear_frame_queue()
    restore_color_filter()
    print("[RESET] Đã tắt hiệu ứng và khôi phục trạng thái bộ lọc màu ban đầu.")

# =========================================================
# HOTKEYS
# =========================================================
def enqueue_command(command):
    if running:
        command_queue.put(command)


def normalize_key_name(name):
    name = (name or "").lower()
    for prefix in ("left ", "right "):
        if name.startswith(prefix):
            return name[len(prefix):]
    if name == "escape":
        return "esc"
    return name


def keyboard_event_handler(event):
    global last_esc_press
    if not running:
        return
    try:
        name = normalize_key_name(event.name)
        code = event.scan_code
        if not name:
            return

        with hotkey_lock:
            if event.event_type == "up":
                pressed_keys.pop(code, None)
                held = set(pressed_keys.values())
                if not CHORD_GRAYSCALE <= held:
                    triggered_chords.discard("grayscale")
                if not CHORD_FPS <= held:
                    triggered_chords.discard("fps")
                return

            if code in pressed_keys:  # bỏ qua key-down lặp khi giữ phím
                return
            pressed_keys[code] = name
            held = set(pressed_keys.values())

            if name == "f12":
                enqueue_command("exit")
                return

            if CHORD_GRAYSCALE <= held:
                if "grayscale" not in triggered_chords:
                    triggered_chords.add("grayscale")
                    last_esc_press = 0.0
                    enqueue_command("grayscale")
                return

            if CHORD_FPS <= held:
                if "fps" not in triggered_chords:
                    triggered_chords.add("fps")
                    last_esc_press = 0.0
                    enqueue_command("fps")
                return

            if name == "esc":
                if any(key in held for key in ("ctrl", "w", "1", "e")):
                    last_esc_press = 0.0
                    return
                now = time.monotonic()
                if last_esc_press and now - last_esc_press <= ESC_DOUBLE_PRESS_INTERVAL:
                    last_esc_press = 0.0
                    enqueue_command("reset")
                else:
                    last_esc_press = now
    except Exception as exc:
        print(f"[HOTKEY ERROR] {exc}")


def register_hotkeys():
    keyboard.hook(keyboard_event_handler)

# =========================================================
# UI UPDATE
# =========================================================
def service_hide_requests():
    global capture_in_progress
    while True:
        try:
            ack = hide_queue.get_nowait()
        except queue.Empty:
            return
        with state_lock:
            active = fps_enabled
        if active:
            capture_in_progress = True
            hide_overlay()
            root.update_idletasks()
            root.after(HIDE_SETTLE_MS, ack.set)
        else:
            capture_in_progress = False
            ack.set()


def run_command(command):
    global capture_in_progress
    if command == "grayscale":
        toggle_grayscale()
    elif command == "fps":
        toggle_fps()
    elif command == "reset":
        disable_all_effects()
    elif command == "capture_done":
        capture_in_progress = False
    elif command == "exit":
        shutdown()


def show_latest_frame():
    global photo_image
    with state_lock:
        active = fps_enabled
    if not active or capture_in_progress:
        return
    try:
        image = frame_queue.get_nowait()
    except queue.Empty:
        return
    photo_image = ImageTk.PhotoImage(image)
    screen_label.configure(image=photo_image)
    show_overlay()


def process_commands():
    if not running:
        return
    try:
        service_hide_requests()
        while running:
            try:
                command = command_queue.get_nowait()
            except queue.Empty:
                break
            run_command(command)
        if running:
            show_latest_frame()
    except Exception as exc:
        print(f"[UI ERROR] {exc}")
    finally:
        if running:
            root.after(POLL_INTERVAL_MS, process_commands)

# =========================================================
# SHUTDOWN / MAIN
# =========================================================
def shutdown():
    global running, fps_enabled, capture_in_progress
    if not running:
        return
    running = False
    stop_event.set()
    with state_lock:
        fps_enabled = False
    capture_in_progress = False
    try:
        root.withdraw()
    except Exception:
        pass
    restore_color_filter()
    try:
        keyboard.unhook_all()
    except Exception:
        pass
    try:
        root.destroy()
    except Exception:
        pass
    print("[EXIT] Đã đóng chương trình.")


def main():
    global initial_filter_state, monitor_rect
    request_admin()
    enable_dpi_awareness()
    monitor_rect = get_monitor_rect()
    if monitor_rect is None:
        print("Không tìm thấy màn hình chính. Kiểm tra MONITOR_INDEX.")
        return
    initial_filter_state = read_filter_state()

    print("=" * 45)
    print("WINDOWS EFFECT SIMULATOR")
    print("Ctrl + W + Esc : Bật/tắt bộ lọc màu")
    print("Esc, Esc       : Tắt hiệu ứng, khôi phục màu ban đầu")
    print("Esc + 1 + E    : Bật/tắt mô phỏng 10 FPS")
    print("F12            : Thoát và khôi phục màu ban đầu")
    print("=" * 45)

    create_window()
    if USE_CAPTURE_EXCLUSION and not capture_excluded:
        print("[OVERLAY] Không bật được capture exclusion; dùng chế độ ẩn lớp phủ khi chụp.")
    register_hotkeys()
    signal.signal(signal.SIGINT, lambda *_: enqueue_command("exit"))

    thread = threading.Thread(target=capture_loop, args=(monitor_rect,), daemon=True)
    thread.start()
    root.after(POLL_INTERVAL_MS, process_commands)
    try:
        root.mainloop()
    finally:
        if running:
            shutdown()


if __name__ == "__main__":
    main()
